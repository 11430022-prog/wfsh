// Mione external library: winapi
// Allows Mione programs to call any Windows API function directly; used with `enter` from Module/winapi/winapi.mio.
//
// Build (in an x64 Developer Command Prompt, from this folder):
//   cl /nologo /LD /O2 /utf-8 /I "D:\MioneClaude\Mione" winapi.c user32.lib gdi32.lib /Fe:winapi.dll
//
// Functions:
//   call(dll, function name, arguments...)   calls a Windows API function and returns (return value, GetLastError)
//                                Arguments: number -> integer, true/false -> 1/0, null -> 0, string -> address of a temporary string
//                                (UTF-16 when the function name ends with W, otherwise the system code page).
//                                Strings are valid only during the call. At most 16 arguments are supported.
//   alloc(size) / release(address)  allocates / frees a zero-filled memory block (for APIs that need a buffer)
//   peek(address, offset, byte count) / poke(address, offset, byte count, value)   read / write an integer
//   wstring(address)                reads a UTF-16 string as a Mione string
//   wset(address, offset, text)     writes a string to memory as UTF-16 (including the terminating zero)
//   callpointer(address, arguments...)  calls a function pointer (e.g. a COM interface method); returns the same values as call
//   register_class()             registers the window class "MioneWindow" and returns its name
//   theme(background, text)      background color of MioneWindow and color of its static text / read-only edit controls (COLORREF)
//   button_colors(HWND, text, background, pressed, border)
//                                sets the colors of an owner-drawn button (BS_OWNERDRAW); may be changed at any time (e.g. to reflect a judging result)
//   wait()                       runs the message loop until an event occurs and returns (kind, a, b, c, window)
//
// A Mione function cannot serve as a C callback, so this library provides the window procedure (WndProc).
// It only queues events; Mione retrieves them with wait() and handles them itself.
//   "command"  a = control ID, b = notification code (0 for a button click), c = control HWND
//   "size"     a = client width, b = client height, c = WM_SIZE type
//   "close"    a = window HWND (the close button was pressed; Mione decides whether to close and calls DestroyWindow to do so)
//   "timer"    a = timer ID (SetTimer)
//   "vscroll"  a = scroll action (SB_*), b = thumb position
//   "wheel"    a = wheel delta (positive upwards, 120 per notch)
//   The fifth return value (window) is the HWND of the MioneWindow that received the message.
//   "quit"     all MioneWindow windows have been destroyed

#ifndef _WIN64
#error "winapi.dll relies on the x64 calling convention and must be built for x64."
#endif

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

#include "OBJECTS.h"

#define EXPORT __declspec(dllexport)
#define MAX_ARGUMENTS 16

static ExternalLibraryRespondObj Fail(const ExternalLibraryRequestObj Request, char * Message)
{
    ExternalLibraryRespondObj Result = {0};

    Result.Event = Request.EventTemplate;
    Result.Event.Code = EVENT_RUNTIME_ERROR;
    Result.Event.Message = Message;

    return Result;
}

static const ValueObj * Argument(const ExternalLibraryRequestObj Request, const unsigned Index)
{
    static const ValueObj Null = {0};

    return Index < Request.ValueCarrier.CarrierLen ? &Request.ValueCarrier.Carrier[Index] : &Null;
}

//Static array for return values: the interpreter only reads and copies them, so it can be reused without accumulating memory
static ValueObj Answers[5];

static ExternalLibraryRespondObj Respond(const ExternalLibraryRequestObj Request, const unsigned Count)
{
    ExternalLibraryRespondObj Result = {0};

    Result.Event = Request.EventTemplate;
    Result.ValueCarrier.Carrier = Answers;
    Result.ValueCarrier.CarrierLen = Count;

    return Result;
}

static ValueObj NumberValue(const double Number)
{
    return (ValueObj){.ValueType = VALUE_NUMBER_TYPE, .Number = Number};
}

static int ToInteger(const ValueObj * Value, intptr_t * Integer)
{
    switch (Value->ValueType)
    {
    case 0: *Integer = 0; return 1;
    case VALUE_NUMBER_TYPE: *Integer = (intptr_t)(int64_t)Value->Number; return 1;
    case VALUE_DB_TYPE: *Integer = Value->db ? 1 : 0; return 1;
    default: return 0;
    }
}

//Converts UTF-8 to UTF-16 or to the system code page (allocated with malloc)
static void * ConvertString(const char * Text, const int Wide)
{
    const int WideLength = MultiByteToWideChar(CP_UTF8, 0, Text, -1, NULL, 0);
    wchar_t * WideText = malloc(sizeof(wchar_t) * (WideLength > 0 ? WideLength : 1));

    WideText[0] = 0;
    MultiByteToWideChar(CP_UTF8, 0, Text, -1, WideText, WideLength);

    if (Wide)
        return WideText;

    const int AnsiLength = WideCharToMultiByte(CP_ACP, 0, WideText, -1, NULL, 0, NULL, NULL);
    char * AnsiText = malloc(AnsiLength > 0 ? AnsiLength : 1);

    AnsiText[0] = 0;
    WideCharToMultiByte(CP_ACP, 0, WideText, -1, AnsiText, AnsiLength, NULL, NULL);
    free(WideText);

    return AnsiText;
}

//////////////////////////////////////// call ////////////////////////////////////////

typedef intptr_t (*GenericFunction)(
    intptr_t, intptr_t, intptr_t, intptr_t, intptr_t, intptr_t, intptr_t, intptr_t,
    intptr_t, intptr_t, intptr_t, intptr_t, intptr_t, intptr_t, intptr_t, intptr_t);

//Calls Function with the values from index First onwards; Wide selects UTF-16 or the system code page for string arguments
static ExternalLibraryRespondObj Invoke(const ExternalLibraryRequestObj Request, const GenericFunction Function, const unsigned First, const int Wide)
{
    const unsigned Count = Request.ValueCarrier.CarrierLen > First ? Request.ValueCarrier.CarrierLen - First : 0;

    if (Count > MAX_ARGUMENTS)
        return Fail(Request, "call: too many arguments (at most 16).");

    intptr_t Arguments[MAX_ARGUMENTS] = {0};
    void * Temporary[MAX_ARGUMENTS] = {0};

    for (unsigned Index = 0; Index < Count; Index++)
    {
        const ValueObj * Value = Argument(Request, Index + First);

        if (Value->ValueType == VALUE_STRING_TYPE)
        {
            Temporary[Index] = ConvertString(Value->String, Wide);
            Arguments[Index] = (intptr_t)Temporary[Index];
        }else if (!ToInteger(Value, &Arguments[Index]))
        {
            for (unsigned Used = 0; Used < Index; Used++)
                free(Temporary[Used]);

            return Fail(Request, "call: arguments should be numbers, booleans, strings or null.");
        }
    }

    //Under the x64 calling convention the caller cleans up the stack, so extra arguments are ignored by the callee
    SetLastError(0);

    const intptr_t Returned = Function(
        Arguments[0], Arguments[1], Arguments[2], Arguments[3],
        Arguments[4], Arguments[5], Arguments[6], Arguments[7],
        Arguments[8], Arguments[9], Arguments[10], Arguments[11],
        Arguments[12], Arguments[13], Arguments[14], Arguments[15]);

    const DWORD LastError = GetLastError();

    for (unsigned Index = 0; Index < Count; Index++)
        free(Temporary[Index]);

    Answers[0] = NumberValue((double)(int64_t)Returned);
    Answers[1] = NumberValue((double)LastError);

    return Respond(Request, 2);
}

EXPORT ExternalLibraryRespondObj call(const ExternalLibraryRequestObj Request)
{
    const ValueObj * Library = Argument(Request, 0);
    const ValueObj * Name = Argument(Request, 1);

    if (Library->ValueType != VALUE_STRING_TYPE || Name->ValueType != VALUE_STRING_TYPE)
        return Fail(Request, "call(dll, function, ...): dll and function should be strings.");

    HMODULE Module = LoadLibraryA(Library->String);

    if (!Module)
        return Fail(Request, "call: can not load the dll.");

    const GenericFunction Function = (GenericFunction)(void *)GetProcAddress(Module, Name->String);

    if (!Function)
        return Fail(Request, "call: function not found in the dll.");

    const size_t NameLength = strlen(Name->String);

    return Invoke(Request, Function, 2, NameLength && Name->String[NameLength - 1] == 'W');
}

//Calls a function pointer (e.g. a COM method). String arguments are always converted to UTF-16.
EXPORT ExternalLibraryRespondObj callpointer(const ExternalLibraryRequestObj Request)
{
    intptr_t Address = 0;

    if (!ToInteger(Argument(Request, 0), &Address) || !Address)
        return Fail(Request, "callpointer(address, ...): address should be a non-zero number.");

    return Invoke(Request, (GenericFunction)Address, 1, 1);
}

//////////////////////////////////////// Memory ////////////////////////////////////////

EXPORT ExternalLibraryRespondObj alloc(const ExternalLibraryRequestObj Request)
{
    const ValueObj * Size = Argument(Request, 0);

    if (Size->ValueType != VALUE_NUMBER_TYPE || Size->Number < 0)
        return Fail(Request, "alloc(size): size should be a positive number.");

    void * Memory = calloc(1, (size_t)Size->Number + 2); //Extra terminating zeros make the block safe to use as a string

    if (!Memory)
        return Fail(Request, "alloc: out of memory.");

    Answers[0] = NumberValue((double)(intptr_t)Memory);

    return Respond(Request, 1);
}

EXPORT ExternalLibraryRespondObj release(const ExternalLibraryRequestObj Request)
{
    intptr_t Address = 0;

    if (!ToInteger(Argument(Request, 0), &Address))
        return Fail(Request, "release(address): address should be a number.");

    free((void *)Address);

    return Respond(Request, 0);
}

static int ReadAccess(const ExternalLibraryRequestObj Request, unsigned char ** Pointer, unsigned * Size)
{
    intptr_t Address = 0, Offset = 0, Bytes = 0;

    if (!ToInteger(Argument(Request, 0), &Address)
        || !ToInteger(Argument(Request, 1), &Offset)
        || !ToInteger(Argument(Request, 2), &Bytes)
        || !Address
        || (Bytes != 1 && Bytes != 2 && Bytes != 4 && Bytes != 8))
        return 0;

    *Pointer = (unsigned char *)Address + Offset;
    *Size = (unsigned)Bytes;

    return 1;
}

EXPORT ExternalLibraryRespondObj peek(const ExternalLibraryRequestObj Request)
{
    unsigned char * Pointer;
    unsigned Size;

    if (!ReadAccess(Request, &Pointer, &Size))
        return Fail(Request, "peek(address, offset, bytes): bytes should be 1, 2, 4 or 8.");

    int64_t Value = 0;

    switch (Size)
    {
    case 1: Value = *(int8_t *)Pointer; break;
    case 2: Value = *(int16_t *)Pointer; break;
    case 4: Value = *(int32_t *)Pointer; break;
    default: Value = *(int64_t *)Pointer; break;
    }

    Answers[0] = NumberValue((double)Value);

    return Respond(Request, 1);
}

EXPORT ExternalLibraryRespondObj poke(const ExternalLibraryRequestObj Request)
{
    unsigned char * Pointer;
    unsigned Size;
    intptr_t Value = 0;

    if (!ReadAccess(Request, &Pointer, &Size) || !ToInteger(Argument(Request, 3), &Value))
        return Fail(Request, "poke(address, offset, bytes, value): bytes should be 1, 2, 4 or 8.");

    switch (Size)
    {
    case 1: *(int8_t *)Pointer = (int8_t)Value; break;
    case 2: *(int16_t *)Pointer = (int16_t)Value; break;
    case 4: *(int32_t *)Pointer = (int32_t)Value; break;
    default: *(int64_t *)Pointer = (int64_t)Value; break;
    }

    return Respond(Request, 0);
}

EXPORT ExternalLibraryRespondObj wstring(const ExternalLibraryRequestObj Request)
{
    intptr_t Address = 0;

    if (!ToInteger(Argument(Request, 0), &Address) || !Address)
        return Fail(Request, "wstring(address): address should be a non-zero number.");

    const wchar_t * WideText = (const wchar_t *)Address;
    const int Length = WideCharToMultiByte(CP_UTF8, 0, WideText, -1, NULL, 0, NULL, NULL);
    char * Text = malloc(Length > 0 ? Length : 1);

    Text[0] = 0;
    WideCharToMultiByte(CP_UTF8, 0, WideText, -1, Text, Length, NULL, NULL);

    Answers[0] = (ValueObj){.ValueType = VALUE_STRING_TYPE, .String = Text};

    return Respond(Request, 1);
}

EXPORT ExternalLibraryRespondObj wset(const ExternalLibraryRequestObj Request)
{
    intptr_t Address = 0, Offset = 0;
    const ValueObj * Text = Argument(Request, 2);

    if (!ToInteger(Argument(Request, 0), &Address) || !Address || !ToInteger(Argument(Request, 1), &Offset) || Text->ValueType != VALUE_STRING_TYPE)
        return Fail(Request, "wset(address, offset, text): text should be a string.");

    wchar_t * WideText = ConvertString(Text->String, 1);

    memcpy((char *)Address + Offset, WideText, sizeof(wchar_t) * (wcslen(WideText) + 1));
    free(WideText);

    return Respond(Request, 0);
}

//////////////////////////////////////// Theme ////////////////////////////////////////

//Mione cannot handle painting messages such as WM_DRAWITEM that require an immediate response, so Mione chooses the colors and this library paints

static HBRUSH ThemeBackBrush = NULL;
static COLORREF ThemeBack = 0;
static COLORREF ThemeText = 0;

typedef struct
{
    COLORREF Text, Back, Pressed, Border;
} ButtonStyle;

static const wchar_t ButtonStyleProperty[] = L"MioneButtonStyle";

EXPORT ExternalLibraryRespondObj theme(const ExternalLibraryRequestObj Request)
{
    intptr_t Back = 0, Text = 0;

    if (!ToInteger(Argument(Request, 0), &Back) || !ToInteger(Argument(Request, 1), &Text))
        return Fail(Request, "theme(background, text): colors should be numbers (COLORREF).");

    if (ThemeBackBrush)
        DeleteObject(ThemeBackBrush);

    ThemeBack = (COLORREF)Back;
    ThemeText = (COLORREF)Text;
    ThemeBackBrush = CreateSolidBrush(ThemeBack);

    return Respond(Request, 0);
}

EXPORT ExternalLibraryRespondObj button_colors(const ExternalLibraryRequestObj Request)
{
    intptr_t Window = 0, Text = 0, Back = 0, Pressed = 0, Border = 0;

    if (!ToInteger(Argument(Request, 0), &Window) || !Window
        || !ToInteger(Argument(Request, 1), &Text) || !ToInteger(Argument(Request, 2), &Back)
        || !ToInteger(Argument(Request, 3), &Pressed) || !ToInteger(Argument(Request, 4), &Border))
        return Fail(Request, "button_colors(hwnd, text, back, pressed, border): arguments should be numbers.");

    ButtonStyle * Style = GetPropW((HWND)Window, ButtonStyleProperty);

    if (!Style)
    {
        Style = malloc(sizeof(ButtonStyle));
        SetPropW((HWND)Window, ButtonStyleProperty, Style);
    }

    *Style = (ButtonStyle){(COLORREF)Text, (COLORREF)Back, (COLORREF)Pressed, (COLORREF)Border};

    InvalidateRect((HWND)Window, NULL, TRUE);

    return Respond(Request, 0);
}

static COLORREF Blend(const COLORREF A, const COLORREF B)
{
    return RGB((GetRValue(A) + GetRValue(B)) / 2, (GetGValue(A) + GetGValue(B)) / 2, (GetBValue(A) + GetBValue(B)) / 2);
}

static void DrawStyledButton(const DRAWITEMSTRUCT * Item, const ButtonStyle * Style)
{
    const int Disabled = (Item->itemState & ODS_DISABLED) != 0;
    const COLORREF Back = (Item->itemState & ODS_SELECTED) ? Style->Pressed : Style->Back;

    HBRUSH BackBrush = CreateSolidBrush(Back);
    FillRect(Item->hDC, &Item->rcItem, BackBrush);
    DeleteObject(BackBrush);

    HBRUSH BorderBrush = CreateSolidBrush(Style->Border);
    FrameRect(Item->hDC, &Item->rcItem, BorderBrush);
    DeleteObject(BorderBrush);

    wchar_t Text[512];
    GetWindowTextW(Item->hwndItem, Text, 512);

    RECT TextRect = Item->rcItem;
    InflateRect(&TextRect, -6, 0);

    HFONT Font = (HFONT)SendMessageW(Item->hwndItem, WM_GETFONT, 0, 0);
    HGDIOBJ OldFont = Font ? SelectObject(Item->hDC, Font) : NULL;

    SetBkMode(Item->hDC, TRANSPARENT);
    SetTextColor(Item->hDC, Disabled ? Blend(Style->Text, Back) : Style->Text);
    DrawTextW(Item->hDC, Text, -1, &TextRect, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX);

    if (OldFont)
        SelectObject(Item->hDC, OldFont);
}

//////////////////////////////////////// Windows and events ////////////////////////////////////////

typedef struct
{
    const char * Kind;
    double A, B, C;
    double Window;
} WindowEvent;

static WindowEvent * Events = NULL;
static size_t EventHead = 0, EventLength = 0, EventCapacity = 0;
static int AliveWindows = 0;

static void PushEvent(const HWND Window, const char * Kind, const double A, const double B, const double C)
{
    const WindowEvent Event = {Kind, A, B, C, (double)(intptr_t)Window};

    //Consecutive size / timer / vscroll events of the same window are merged, keeping only the latest one
    if (EventLength)
    {
        WindowEvent * Last = &Events[EventHead + EventLength - 1];

        if (Last->Window == Event.Window && strcmp(Last->Kind, Kind) == 0
            && (strcmp(Kind, "size") == 0 || (strcmp(Kind, "timer") == 0 && Last->A == A) || (strcmp(Kind, "vscroll") == 0 && Last->A == A)))
        {
            *Last = Event;
            return;
        }
    }

    if (EventHead + EventLength >= EventCapacity)
    {
        if (EventHead) //Reclaim the space of events that were already taken
        {
            memmove(Events, Events + EventHead, sizeof(WindowEvent) * EventLength);
            EventHead = 0;
        }

        if (EventLength >= EventCapacity)
        {
            EventCapacity = EventCapacity ? EventCapacity * 2 : 32;
            Events = realloc(Events, sizeof(WindowEvent) * EventCapacity);
        }
    }

    Events[EventHead + EventLength++] = Event;
}

static LRESULT CALLBACK MioneWindowProcedure(HWND Window, UINT Message, WPARAM WParam, LPARAM LParam)
{
    switch (Message)
    {
    case WM_CREATE:
        AliveWindows++;
        break;
    case WM_COMMAND:
        PushEvent(Window, "command", LOWORD(WParam), HIWORD(WParam), (double)(intptr_t)LParam);
        return 0;
    case WM_TIMER:
        PushEvent(Window, "timer", (double)WParam, 0, 0);
        return 0;
    case WM_VSCROLL:
        PushEvent(Window, "vscroll", LOWORD(WParam), HIWORD(WParam), (double)(intptr_t)LParam);
        return 0;
    case WM_MOUSEWHEEL:
        PushEvent(Window, "wheel", (short)HIWORD(WParam), 0, 0);
        return 0;
    case WM_SIZE:
        PushEvent(Window, "size", LOWORD(LParam), HIWORD(LParam), (double)WParam);
        return 0;
    case WM_CTLCOLORSTATIC: //Static text and read-only edit controls use the theme() colors (system white if not set)
        if (ThemeBackBrush)
        {
            SetTextColor((HDC)WParam, ThemeText);
            SetBkColor((HDC)WParam, ThemeBack);
            return (LRESULT)ThemeBackBrush;
        }
        SetBkColor((HDC)WParam, GetSysColor(COLOR_WINDOW));
        return (LRESULT)GetSysColorBrush(COLOR_WINDOW);
    case WM_ERASEBKGND:
        if (ThemeBackBrush)
        {
            RECT Client;
            GetClientRect(Window, &Client);
            FillRect((HDC)WParam, &Client, ThemeBackBrush);
            return 1;
        }
        break;
    case WM_DRAWITEM:
        {
            const DRAWITEMSTRUCT * Item = (const DRAWITEMSTRUCT *)LParam;
            const ButtonStyle * Style = Item->CtlType == ODT_BUTTON ? GetPropW(Item->hwndItem, ButtonStyleProperty) : NULL;

            if (Style)
            {
                DrawStyledButton(Item, Style);
                return TRUE;
            }
            break;
        }
    case WM_CLOSE:
        PushEvent(Window, "close", (double)(intptr_t)Window, 0, 0);
        return 0;
    case WM_DESTROY:
        if (--AliveWindows <= 0)
            PostQuitMessage(0);
        return 0;
    default:
        break;
    }

    return DefWindowProcW(Window, Message, WParam, LParam);
}

EXPORT ExternalLibraryRespondObj register_class(const ExternalLibraryRequestObj Request)
{
    static int Registered = 0;

    if (!Registered)
    {
        WNDCLASSEXW Class = {0};
        Class.cbSize = sizeof(Class);
        Class.style = CS_HREDRAW | CS_VREDRAW | CS_GLOBALCLASS;
        Class.lpfnWndProc = MioneWindowProcedure;
        Class.hInstance = GetModuleHandleW(NULL);
        Class.hCursor = LoadCursorW(NULL, (LPCWSTR)IDC_ARROW);
        Class.hIcon = LoadIconW(NULL, (LPCWSTR)IDI_APPLICATION);
        Class.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
        Class.lpszClassName = L"MioneWindow";

        if (!RegisterClassExW(&Class))
            return Fail(Request, "register: RegisterClassExW failed.");

        Registered = 1;
    }

    Answers[0] = (ValueObj){.ValueType = VALUE_STRING_TYPE, .String = "MioneWindow"};

    return Respond(Request, 1);
}

EXPORT ExternalLibraryRespondObj wait(const ExternalLibraryRequestObj Request)
{
    while (!EventLength)
    {
        MSG Message;
        const BOOL Got = GetMessageW(&Message, NULL, 0, 0);

        if (Got <= 0) //WM_QUIT or an error
        {
            Answers[0] = (ValueObj){.ValueType = VALUE_STRING_TYPE, .String = "quit"};
            Answers[1] = Answers[2] = Answers[3] = Answers[4] = NumberValue(0);
            return Respond(Request, 5);
        }

        TranslateMessage(&Message);
        DispatchMessageW(&Message);
    }

    const WindowEvent Event = Events[EventHead++];
    EventLength--;

    if (!EventLength)
        EventHead = 0;

    Answers[0] = (ValueObj){.ValueType = VALUE_STRING_TYPE, .String = (char *)Event.Kind};
    Answers[1] = NumberValue(Event.A);
    Answers[2] = NumberValue(Event.B);
    Answers[3] = NumberValue(Event.C);
    Answers[4] = NumberValue(Event.Window);

    return Respond(Request, 5);
}
