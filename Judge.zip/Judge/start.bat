@echo off
rem Mione editor launcher (runs mione\editor.mio)
cd /d "%~dp0"
start "Mione" "%~dp0mione\Mione.exe" "%~dp0mione\editor.mio"
